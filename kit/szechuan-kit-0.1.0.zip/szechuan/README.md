# Szechuan case kit (version 0.1.0)

Windows event logs and tool output from two disk images, plus a summary of Remote Desktop traffic
from a packet capture. Install this directory at `/cases/szechuan/`. Treat everything here as
evidence: read it, copy it, never edit it in place.

## Credit and terms

The source evidence is **"Case 001: The Stolen Szechuan Sauce" from DFIR Madness**
(<https://dfirmadness.com/the-stolen-szechuan-sauce/>), created by the site's author, James
(<https://dfirmadness.com/author/smithsjames/>). It is used here for teaching with credit to the site
and its author, as the case page asks of teachers and students. This kit is a derived extract of that case: the
event logs are byte-for-byte copies from the images, and everything under `derived/` is tool output
made from them.

## What is and is not in the kit

- `evidence/<HOST>/evtx/`: every **non-empty** event log (`.evtx`) from
  `Windows/System32/winevt/Logs/` on each disk image. Empty logs (no records) are listed in the
  inventory file but not shipped.
- `derived/<HOST>/`: the EvtxECmd CSV of those logs, the RegRipper output from the host's `SYSTEM`
  and `SOFTWARE` registry hives, and an inventory of every log file in the image.
- `derived/NETWORK/rdp-sensor-summary.txt`: a summary of TCP 3389 traffic made from the case
  packet capture, standing in for a network sensor.
- **No executable content from the images is included.** The kit contains only event logs and text.
  **No registry hive is included**; only RegRipper's text output from two hives is.

Hosts: `DC01` is the image `20200918_0347_CDrive.E01` (computer name in its registry: CITADEL-DC01);
`DESKTOP-SDN1RPT` is the image `20200918_0417_DESKTOP-SDN1RPT.E01`.

## Files

| File | Size (bytes) | What it is |
|---|---:|---|
| `MANIFEST.sha256` | — | SHA-256 of every other file in the kit (sha256sum -c format). |
| `README.md` | — | This file. |
| `derived/DC01/DC01-evtx-inventory.tsv` | 21,240 | Every .evtx file in the image's Logs folder: original and kit name, MFT entry, Sleuth Kit address, size, SHA-256, record count (evtxinfo), whether shipped. |
| `derived/DC01/DC01-evtxecmd.csv` | 36,072,345 | EvtxECmd CSV of every log in evidence/<HOST>/evtx/, one record per line, UTC. |
| `derived/DC01/DC01-registry.txt` | 1,233 | RegRipper output (compname, timezone, winver) from the host's SYSTEM and SOFTWARE hives. |
| `derived/DESKTOP-SDN1RPT/DESKTOP-SDN1RPT-evtx-inventory.tsv` | 32,110 | Every .evtx file in the image's Logs folder: original and kit name, MFT entry, Sleuth Kit address, size, SHA-256, record count (evtxinfo), whether shipped. |
| `derived/DESKTOP-SDN1RPT/DESKTOP-SDN1RPT-evtxecmd.csv` | 29,675,743 | EvtxECmd CSV of every log in evidence/<HOST>/evtx/, one record per line, UTC. |
| `derived/DESKTOP-SDN1RPT/DESKTOP-SDN1RPT-registry.txt` | 1,493 | RegRipper output (compname, timezone, winver) from the host's SYSTEM and SOFTWARE hives. |
| `derived/NETWORK/rdp-sensor-summary.txt` | 2,485 | Network sensor summary of TCP 3389 traffic, made from the case packet capture. |
| `evidence/DC01/evtx/Active_Directory_Web_Services.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Application.evtx` | 1,118,208 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/DFS_Replication.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/DNS_Server.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Directory_Service.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-AppReadiness%4Admin.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-AppReadiness%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-AppXDeployment%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-AppXDeploymentServer%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-Application-Experience%4Program-Inventory.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-Application-Experience%4Program-Telemetry.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-ApplicationResourceManagementSystem%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-Bits-Client%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-CoreApplication%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-Crypto-DPAPI%4BackUpKeySvc.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-Crypto-DPAPI%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-DataIntegrityScan%4Admin.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-DeviceSetupManager%4Admin.evtx` | 1,052,672 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-DeviceSetupManager%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-Dhcp-Client%4Admin.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-Diagnosis-DPS%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-Diagnosis-Scripted%4Admin.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-Diagnosis-Scripted%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-Diagnostics-Networking%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-DirectoryServices-Deployment%4Operational.evtx` | 1,052,672 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-FileServices-ServerManager-EventProvider%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-Forwarding%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-GroupPolicy%4Operational.evtx` | 2,166,784 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-International%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-Kernel-PnP%4Configuration.evtx` | 1,052,672 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-Kernel-PnPConfig%4Configuration.evtx` | 1,052,672 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-Kernel-ShimEngine%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-Kernel-WHEA%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-Known_Folders_API_Service.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-MUI%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-NCSI%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-NetworkProfile%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-NlaSvc%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-Ntfs%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-Ntfs%4WHC.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-PowerShell%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-PrintService%4Admin.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-RemoteDesktopServices-RdpCoreTS%4Operational.evtx` | 1,052,672 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-Resource-Exhaustion-Detector%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-SMBServer%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-Security-SPP-UX-Notifications%4ActionCenter.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-ServerManager-DeploymentProvider%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-ServerManager-MgmtProvider%4Operational.evtx` | 1,052,672 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-ServerManager-MultiMachine%4Operational.evtx` | 1,052,672 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-Shell-Core%4Operational.evtx` | 1,052,672 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-SmartCard-DeviceEnum%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-SmbClient%4Connectivity.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-TWinUI%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-TaskScheduler%4Maintenance.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-TaskScheduler%4Operational.evtx` | 1,118,208 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-TerminalServices-LocalSessionManager%4Operational.evtx` | 1,052,672 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-TerminalServices-RDPClient%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-TerminalServices-RemoteConnectionManager%4Admin.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-TerminalServices-RemoteConnectionManager%4Operational.evtx` | 1,052,672 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-UserPnp%4DeviceInstall.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-User_Profile_Service%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-WER-Diag%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-WMI-Activity%4Operational.evtx` | 1,052,672 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-Wcmsvc%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-WinINet-Config%4ProxyConfigChanged.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-WinRM%4Operational.evtx` | 1,052,672 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Microsoft-Windows-Windows_Firewall_With_Advanced_Security%4Firewall.evtx` | 1,052,672 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Security.evtx` | 6,361,088 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Setup.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/System.evtx` | 16,846,848 | Windows event log extracted read-only from the disk image. |
| `evidence/DC01/evtx/Windows_PowerShell.evtx` | 1,118,208 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Application.evtx` | 1,118,208 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Client-Licensing-Platform%4Admin.evtx` | 1,052,672 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-AAD%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-AppModel-Runtime%4Admin.evtx` | 1,052,672 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-AppReadiness%4Admin.evtx` | 1,118,208 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-AppReadiness%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-AppXDeployment%4Operational.evtx` | 1,052,672 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-AppXDeploymentServer%4Operational.evtx` | 5,246,976 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-Application-Experience%4Program-Telemetry.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-AppxPackaging%4Operational.evtx` | 1,052,672 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-Audio%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-Authentication_User_Interface%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-Biometrics%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-BitLocker%4BitLocker_Management.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-Bits-Client%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-CloudStore%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-CodeIntegrity%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-Containers-BindFlt%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-Containers-Wcifs%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-CoreSystem-SmsRouter-Events%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-Crypto-DPAPI%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-Crypto-NCrypt%4Operational.evtx` | 1,052,672 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-DeviceManagement-Enterprise-Diagnostics-Provider%4Admin.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-DeviceManagement-Enterprise-Diagnostics-Provider%4Operational.evtx` | 1,052,672 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-DeviceSetupManager%4Admin.evtx` | 1,052,672 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-DeviceSetupManager%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-Dhcp-Client%4Admin.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-Diagnosis-DPS%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-Diagnostics-Performance%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-GroupPolicy%4Operational.evtx` | 1,118,208 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-HelloForBusiness%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-Kernel-Boot%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-Kernel-EventTracing%4Admin.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-Kernel-PnP%4Configuration.evtx` | 1,052,672 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-Kernel-ShimEngine%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-Kernel-WHEA%4Operational.evtx` | 1,118,208 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-Known_Folders_API_Service.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-LanguagePackSetup%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-LiveId%4Operational.evtx` | 1,052,672 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-MUI%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-ModernDeployment-Diagnostics-Provider%4Autopilot.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-ModernDeployment-Diagnostics-Provider%4ManagementService.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-NCSI%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-NcdAutoSetup%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-NetworkProfile%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-Ntfs%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-Ntfs%4WHC.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-Partition%4Diagnostic.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-PowerShell%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-Privacy-Auditing%4Operational.evtx` | 1,118,208 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-Provisioning-Diagnostics-Provider%4Admin.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-PushNotification-Platform%4Operational.evtx` | 1,052,672 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-ReadyBoost%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-RemoteAssistance%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-RemoteDesktopServices-RdpCoreTS%4Operational.evtx` | 1,052,672 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-Resource-Exhaustion-Detector%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-SMBServer%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-Security-LessPrivilegedAppContainer%4Operational.evtx` | 1,052,672 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-Security-Mitigations%4KernelMode.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-Security-SPP-UX-Notifications%4ActionCenter.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-SettingSync%4Debug.evtx` | 1,052,672 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-SettingSync%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-Shell-Core%4AppDefaults.evtx` | 1,052,672 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-Shell-Core%4Operational.evtx` | 1,052,672 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-ShellCommon-StartLayoutPopulation%4Operational.evtx` | 1,052,672 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-SmartCard-DeviceEnum%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-SmbClient%4Connectivity.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-StateRepository%4Operational.evtx` | 1,118,208 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-Storage-ClassPnP%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-Storage-Storport%4Health.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-Storage-Storport%4Operational.evtx` | 1,118,208 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-StorageSpaces-Driver%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-Store%4Operational.evtx` | 8,458,240 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-Storsvc%4Diagnostic.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-TWinUI%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-TaskScheduler%4Maintenance.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-TaskScheduler%4Operational.evtx` | 1,118,208 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-TerminalServices-LocalSessionManager%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-TerminalServices-PnPDevices%4Admin.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-TerminalServices-RemoteConnectionManager%4Admin.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-TerminalServices-RemoteConnectionManager%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-TerminalServices-ServerUSBDevices%4Admin.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-Time-Service%4Operational.evtx` | 1,052,672 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-UniversalTelemetryClient%4Operational.evtx` | 1,052,672 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-UserPnp%4DeviceInstall.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-User_Device_Registration%4Admin.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-User_Profile_Service%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-VolumeSnapshot-Driver%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-WER-PayloadHealth%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-WFP%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-WMI-Activity%4Operational.evtx` | 1,052,672 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-Wcmsvc%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-WebAuthN%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-WinINet-Config%4ProxyConfigChanged.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-WinRM%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-WindowsUpdateClient%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-Windows_Defender%4Operational.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-Windows_Firewall_With_Advanced_Security%4Firewall.evtx` | 1,052,672 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Microsoft-Windows-Winlogon%4Operational.evtx` | 1,052,672 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Security.evtx` | 2,166,784 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/System.evtx` | 1,118,208 | Windows event log extracted read-only from the disk image. |
| `evidence/DESKTOP-SDN1RPT/evtx/Windows_PowerShell.evtx` | 69,632 | Windows event log extracted read-only from the disk image. |
| `tools.list` | 86 | Tools the kit needs, for the lab toolkit's readiness check. |

## Source images

| Host | Image (first segment) | Case zip SHA-256 | Image MD5 (stored in E01 = recomputed by `ewfverify`) | Image SHA-1 (stored) | Image SHA-256 (computed by `ewfverify -d sha256`) | Windows volume |
|---|---|---|---|---|---|---|
| DC01 | `E01-DC01/20200918_0347_CDrive.E01` (+ `.E02`) | `efe06d12388dbc000fa4ae306746ddaca3893a6cdbd55311b52f5833e717acd9` (`DC01-E01.zip`) | `58c73a9c4b223382eb7b89a5008eada3` | `8a92c0197854b3c60b121baf6c4aae276e338f9d` | `01bd2411157c1bb09f1b514e64f8aec7c353750adc44ea52a1c733a8ad563a39` | NTFS partition at sector 718848 |
| DESKTOP-SDN1RPT | `20200918_0417_DESKTOP-SDN1RPT.E01` (+ `.E02`–`.E04`) | `ade4c11a695bdcbe89d76ca0949ac918456549fcca9e4558502ffc286c8d16ad` (`DESKTOP-E01.zip`) | `bcd3aef20406df00585341f0c743a1ce` | `2f9232ff6537f6d4fb26cb397e4becb5d5cd5896` | `7d0877a6dc615671b5228867b584af57db5a2549f515db9600f7773292822b6f` | NTFS partition at sector 239616 |

Packet capture: `case001.pcap` from `case001-pcap.zip`
(zip SHA-256 `ea8eee228cdf82b1f534a2daab88dfb1d928d2ef2d5b469c189242d8c901f0ec`,
pcap SHA-256 `09abf49efea1852e047987d92907704d47f36d75f6c8056e2cafa6cc027791cb`).

## How it was produced

All steps ran inside a SIFT Workstation VM built from `sift-2026-04-22.ova` (Ubuntu 24.04), with the
tools that ship in it. Paths contain no spaces.

1. **Integrity.** `ewfinfo <E01>`, `ewfverify -d sha256 <E01>` (libewf 20140816; both images:
   `ewfverify: SUCCESS`, stored MD5 = calculated MD5), `mmls <E01>` (The Sleuth Kit 4.11.1).
2. **Extraction, read-only, straight from the E01 with The Sleuth Kit.**
   `ifind -o <offset> -n /Windows/System32/winevt/Logs <E01>` and `.../config` to find the
   directories, `fls -o <offset> <E01> <dir-entry>` to list them, then for each allocated `.evtx`
   file and for the `SYSTEM` and `SOFTWARE` hives `icat -o <offset> <E01> <MFT-entry>-128-<id>`.
   The MFT entry, Sleuth Kit address, size and SHA-256 of every extracted log are in
   `derived/<HOST>/<HOST>-evtx-inventory.tsv`.
   **File names:** spaces in log names were replaced with `_` (for example
   `Windows PowerShell.evtx` -> `Windows_PowerShell.evtx`), because the SIFT `EvtxECmd` wrapper
   silently does nothing when given a path that contains a space. The inventory gives both names.
   The bytes are unchanged; the SHA-256 in the inventory is that of the file as shipped.
3. **Record counts.** `evtxinfo <file>` (libevtx 20251118) for every extracted log; the counts are
   the `records_evtxinfo` column of the inventory and equal the number of CSV rows per file.
4. **Event-log CSV.** EvtxECmd version 1.5.2.0 (`1.5.2+e578162a386431c14d8ed4dfe1bc011b3f68438c`,
   .NET 9, default maps in `/opt/zimmermantools/EvtxeCmd/Maps`, 453 maps loaded), run with the logs at
   their kit paths:
   `EvtxECmd -d /cases/szechuan/evidence/<HOST>/evtx --csv <dir> --csvf <HOST>-evtxecmd.csv`
   (defaults otherwise, including `--dedupe` and the default time format
   `yyyy-MM-dd HH:mm:ss.fffffff`).
   **One record per line:** EvtxECmd writes some values with embedded line breaks (only in
   `PayloadData1`–`PayloadData3` of "Windows PowerShell" channel events 400, 403 and 600: 114 rows on
   DC01, 15 on the desktop). One deterministic step followed: inside double-quoted CSV fields every
   CR byte was replaced with the two characters `\r` and every LF byte with `\n`. Nothing outside
   quoted fields changed, so every other row is byte-identical to EvtxECmd's own output. To reproduce
   a row of another channel, run EvtxECmd on the file at the same path and compare directly.
5. **Registry.** RegRipper (Rip v.3.0): `rip.pl -r SYSTEM -p compname`, `rip.pl -r SYSTEM -p timezone`,
   `rip.pl -r SOFTWARE -p winver`. RegRipper does not replay hive transaction logs, which were not
   extracted.
6. **Network sensor summary.** `tcpdump -n -tt -r case001.pcap 'tcp port 3389'` (tcpdump 4.99.4,
   libpcap 1.10.4), summarised per client/server pair by a short standard-library Python script
   (first and last packet, packets, SYN packets, connection attempts counted as distinct client port +
   initial sequence number, largest connections, attempts per minute). The command lines are at the
   end of the file.

## Reading the CSVs

- UTF-8 with a byte-order mark; records end with CRLF; line 1 is the header.
- Columns: `RecordNumber, EventRecordId, TimeCreated, EventId, Level, Provider, Channel, ProcessId,
  ThreadId, Computer, ChunkNumber, UserId, MapDescription, UserName, RemoteHost, PayloadData1-6,
  ExecutableInfo, HiddenRecord, SourceFile, Keywords, ExtraDataOffset, Payload`. The first seven
  columns never contain commas, so `awk -F,` is safe for them; `Payload` is the full event data as
  JSON (quotes doubled, CSV style).
- `TimeCreated` is the time the host recorded, shown as UTC. It comes from the host's own clock,
  which may itself be wrong; this kit does not correct any time.
- A citation such as `DC01/Security/7389` means host, `Channel` column, `EventRecordId` column.

## Checking the kit

```
cd /cases/szechuan && sha256sum -c MANIFEST.sha256
```
